package org.bukkit.entity;

/**
 * Represents a MagmaCube.
 */
public interface MagmaCube extends Slime {
}
