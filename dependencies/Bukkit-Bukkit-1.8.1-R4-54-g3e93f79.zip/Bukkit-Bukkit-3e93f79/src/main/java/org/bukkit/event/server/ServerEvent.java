package org.bukkit.event.server;

import org.bukkit.event.Event;

/**
 * Miscellaneous server events
 */
public class ServerEvent extends Event {
    public ServerEvent(final Type type) {
        super(type);
    }
}
