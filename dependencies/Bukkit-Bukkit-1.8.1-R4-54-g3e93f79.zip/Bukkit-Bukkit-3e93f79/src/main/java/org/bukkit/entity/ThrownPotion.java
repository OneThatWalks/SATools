package org.bukkit.entity;

/**
 * Represents a thrown potion bottle
 */
public interface ThrownPotion extends Projectile {
    
}
